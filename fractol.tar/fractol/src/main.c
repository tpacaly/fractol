/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/19 17:03:59 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/24 13:40:38 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fractol.h"

int		ft_lerpi(int first, int second, double p)
{
	if (first == second)
		return (first);
	return ((int)((double)first + (second - first) * p));
}

int		ft_red_cross(void)
{
	exit(0);
	return (1);
}

int		hook_expose(t_mlx *mlx)
{
	render(mlx);
	return (0);
}

int		die(char *reason)
{
	ft_printf("%s\n", reason);
	return (1);
}

int		main(int c, char **v)
{
	t_mlx		*mlx;
	t_fractal	*f;

	if (c < 2)
		return (die("error: not enough arguments"));
	f = fractal_match(v[1]);
	if (f->name == NULL)
		return (die("error: invalid fractal name"));
	if ((mlx = init(f)) == NULL)
		return (die("error: mlx couldn't initialize properly"));
	reset_viewport(mlx);
	render(mlx);
	mlx_key_hook(mlx->window, hook_keydown, mlx);
	mlx_expose_hook(mlx->window, hook_expose, mlx);
	mlx_hook(mlx->window, 17, 0, ft_red_cross, 0);
	mlx_hook(mlx->window, 4, 1L << 2, hook_mousedown, mlx);
	mlx_hook(mlx->window, 5, 1L << 3, hook_mouseup, mlx);
	mlx_hook(mlx->window, 6, 1L << 6, hook_mousemove, mlx);
	mlx_loop(mlx->mlx);
	return (0);
}
