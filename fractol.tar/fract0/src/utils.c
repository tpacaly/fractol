/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/26 12:52:13 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/26 12:52:14 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fractol.h"

int			ft_red_cross(void)
{
	exit(0);
	return (0);
}

void		clear_window(t_benv *be)
{
	int f;

	f = 800 * 800 * 4;
	while (f > 0)
		be->data[--f] = 0;
}

t_benv		ft_init(t_benv be)
{
	be.factor = 1;
	be.movex = 0;
	be.movey = 0;
	be.factorx1 = 0;
	be.factorx2 = 0;
	be.stop = 0;
	be.r = 1;
	be.g = 1;
	be.b = 1;
	be.filr = 0x000000;
	be.filg = 0x000000;
	be.filb = 0x000000;
	be.f = 0x0000ff;
	be.ff = 0x00ff00;
	be.fff = 0xff0000;
	return (be);
}

int			ft_usage(void)
{
	char *c;

	c = "usage : fractol [j] [m] [w]\0";
	ft_printf("%s\n", c);
	return (0);
}
