/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   julia_init.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/26 11:42:01 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/26 12:01:43 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fractol.h"

int			mouse_hook_ju(int button, int x, int y, t_benv *be)
{
	if (button == 4)
	{
		be->factor *= 1.1;
		be->movex += ((double)x - (800 / 2)) * (0.00038 /
				be->factor);
		be->movey += ((double)y - (800 / 2)) * 0.00038 /
			be->factor;
	}
	if (button == 5 || button == 7)
	{
		be->factor /= 1.1;
		be->movex -= ((double)x - (800 / 2)) * 0.00038 /
			(800 / 800) / be->factor;
		be->movey -= ((double)y - (800 / 2)) * 0.00038 /
			(800 / 800) / be->factor;
	}
	expose_hook_ju(be);
	return (0);
}

int			motion_hook(int x, int y, t_benv *be)
{
	mlx_mouse_hook(be->win, mouse_hook_ju, be);
	if (be->stop == 0)
	{
		be->factorx1 = (double)x / 1250 - 1;
		be->factorx2 = (double)y / 450 - 1;
	}
	expose_hook_ju(be);
	return (0);
}

int			key_hook_ju(int keycode, t_benv *be)
{
	if (keycode == 53)
		exit(0);
	else if ((keycode == ' ' || keycode == 49) && be->stop == 1)
		be->stop = 0;
	else if (keycode == ' ' || keycode == 49)
		be->stop = 1;
	else if (keycode == 125 || keycode == 65364)
		be->movey += 0.1 / be->factor;
	else if (keycode == 124 || keycode == 65363)
		be->movex += 0.1 / be->factor;
	else if (keycode == 126 || keycode == 65362)
		be->movey -= 0.1 / be->factor;
	else if (keycode == 123 || keycode == 65361)
		be->movex -= 0.1 / be->factor;
	ft_color(keycode, be);
	expose_hook_ju(be);
	return (0);
}

int			expose_hook_ju(t_benv *be)
{
	clear_window(be);
	mlx_put_image_to_window(be->mlx, be->win, be->img, 0, 0);
	ft_draw_ju(be);
	mlx_put_image_to_window(be->mlx, be->win, be->img, 0, 0);
	return (0);
}
