/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_mandel.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/10/26 11:43:32 by tpacaly           #+#    #+#             */
/*   Updated: 2017/10/26 12:08:27 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fractol.h"

t_env		ft_init_env_mandel(t_benv be)
{
	t_env e;

	if (be.ite_max == ITER_BASE)
		be.ite_max = ITER_BASE_MANDELSHIP;
	e.x1 = -2.1 + be.factorx1;
	e.x2 = 0.6 - be.factorx2;
	e.y1 = -1.2 + be.factory1;
	e.y2 = 1.3 - be.factory2;
	e.zoom = (be.factor);
	e.ite_max = be.ite_max;
	e.image_x = 800;
	e.image_y = 800;
	return (e);
}

int			motion_hook_mand(int x, int y, t_benv *be)
{
	if (be->mouse_acti_ma == 0)
		return (0);
	(void)x;
	(void)y;
	if (FF != 0x0000ff && FF != 0x00ffff && FF != 0xff00ff)
		be->filr += be->f;
	else
		be->filr -= be->f;
	expose_hook_mandel(be);
	return (0);
}

void		ft_draw_mandel(t_benv *be)
{
	t_env	e;

	e = ft_init_env_mandel(*be);
	e.x = 0;
	e.y = 0;
	while (e.x < e.image_x)
	{
		e.y = 0;
		while (e.y < e.image_y)
		{
			e.c_r = 3 * (e.x - 800 / 2) /
				(be->factor * 800) + be->movex;
			e.c_i = 3 * (e.y - 800 / 2) /
				(be->factor * 800) + be->movey;
			e.z_r = 0;
			e.z_i = 0;
			e.i = 0;
			ft_loop_mandel(e, be);
			e.y += 1;
		}
		e.x += 1;
	}
}

t_env		ft_loop_mandel(t_env e, t_benv *be)
{
	while ((e.z_r * e.z_r + e.z_i * e.z_i < 4 && e.i < e.ite_max) ||
				e.i == 0)
	{
		e.tmp = e.z_r;
		e.z_r = e.z_r * e.z_r - e.z_i * e.z_i + e.c_r;
		e.z_i = 2 * e.z_i * e.tmp + e.c_i;
		e.i += 1;
	}
	be->data[e.y * be->size_line + 4 * e.x + 0] = be->b *
		mlx_get_color_value(be->mlx, e.i * (be->filb + FF) / e.ite_max);
	be->data[e.y * be->size_line + 4 * e.x + 1] = be->g *
		mlx_get_color_value(be->mlx, e.i * (be->filg + FF) / e.ite_max);
	be->data[e.y * be->size_line + 4 * e.x + 2] = be->r *
		mlx_get_color_value(be->mlx, e.i * (be->filr + FF) / e.ite_max);
	return (e);
}
